/* ------------------------------------------------------------------------ */
/* Copyright (c) 2017 by Cadence Design Systems, Inc. ALL RIGHTS RESERVED.  */
/* These coded instructions, statements, and computer programs ("Cadence    */
/* Libraries") are the copyrighted works of Cadence Design Systems Inc.	    */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence licensee.                                     */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* DSP Library                                                              */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (C) 2015-2017 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */
/*
	NatureDSP Signal Processing Library. FFT part
    FFT on Complex Data with Optimized Memory Usage
    C code optimized for HiFi3
	Integrit, 2006-2017
*/

#include "NatureDSP_Signal_fft.h"
#include "common.h"

extern int fft_stage_last_ie( int32_t *x, 
                               int32_t *y, 
                               int N); 
/*-------------------------------------------------------------------------
  FFT on Complex Data with Optimized Memory Usage
  These functions make FFT on complex data with optimized memory usage.
  Scaling  : 
      +-------------------+----------------------------------------+
      |      Function     |           Scaling options              |
      +-------------------+----------------------------------------+
      |  fft_cplx16x16_ie |  2 - 16-bit dynamic scaling            | 
      |  fft_cplx24x24_ie |  3 - fixed scaling before each stage   | 
      |  fft_cplx32x16_ie |  3 - fixed scaling before each stage   | 
      |  fft_cplx32x32_ie |  2 - 32-bit dynamic scaling            | 
      |                   |  3 - fixed scaling before each stage   | 
      +-------------------+----------------------------------------+
  NOTES:
  1. Bit-reversing reordering is done here.
  2. FFT runs in-place algorithm so INPUT DATA WILL APPEAR DAMAGED after 
     the call.
  3. FFT of size N may be supplied with constant data
     (twiddle factors) of a larger-sized FFT = N*twdstep.


  Precision: 
  16x16_ie      16-bit input/outputs, 16-bit twiddles
  24x24_ie      24-bit input/outputs, 24-bit twiddles
  32x16_ie      32-bit input/outputs, 16-bit twiddles
  32x32_ie      32-bit input/outputs, 32-bit twiddles
  f_ie          floating point
 
  Input:
  x[N]                  complex input signal. Real and imaginary data 
                        are interleaved and real data goes first
  twd[N*twdstep*3/4]    twiddle factor table of a complex-valued FFT of 
                        size N*twdstep
  N                     FFT size
  twdstep               twiddle step 
  scalingOpt            scaling option (see table above), not applicable
                        to the floating point function 
  Output:
  y[N]                  output spectrum. Real and imaginary data are 
                        interleaved and real data goes first

  Returned value: total number of right shifts occurred during scaling 
                  procedure. Floating function always return 0.

  Restrictions:
  x,y   should not overlap
  x,y   aligned on 8-bytes boundary

-------------------------------------------------------------------------*/

int fft_cplx32x16_ie( complex_fract32* y,complex_fract32* x, const complex_fract16* twd, int twdstep, int N, int scalingOpt)
{
    NASSERT_ALIGN8(x);
    NASSERT_ALIGN8(y);
    NASSERT(scalingOpt==3);
    NASSERT(N==128||N==256||N==512||N==1024);

    int shift = 0;
    int M = twdstep*N;
    int s;
    int tw_step = twdstep;
    int stride = N/4;     

    ae_int32x2 * restrict px;
    ae_int32x2 * restrict py;

    ae_int32   * restrict p16tw1; 
    ae_int32   * restrict p16tw2;
    ae_int32   * restrict p16tw3;
 
    ae_int32x2  vA0, vA1, vA2, vA3, 
                vB0, vB1, vB2, vB3, 
                vC0, vC1, vC2, vC3;
    int i; 
    int log2n = 0; 

    WUR_AE_CBEGIN0((unsigned)x); 
    WUR_AE_CEND0((unsigned)(uintptr_t)(x+(N-1)));     

    s = 3; 

    while( stride > 1 )
    {
        unsigned acc = 0; 
        const unsigned acc_inc  = (log2n==0)? 0: (0x80000000 >> (log2n-1)); 
          
    
        WUR_AE_SAR(s); 
        p16tw1 = (ae_int32*)  twd; 
        p16tw2 = (ae_int32*) (twd+1*M/4);
        p16tw3 = (ae_int32*) (twd+2*M/4);

        log2n += 2;   
        shift += s;
        s = 2; 

        px = (ae_int32x2*)x; 
        py = (ae_int32x2*)x; 
  
        i = N/4;
/*
#<loop> Loop body line 381, nesting depth: 2, estimated iterations: 100
#<swps> 
#<swps>  12 cycles per pipeline stage in steady state with unroll=1
#<swps>   3 pipeline stages
#<swps>  32 real ops (excluding nop)
#<swps> 
#<swps>      min  11 cycles required by resources
#<swps>      min   4 cycles required by recurrences
#<swps>      min  11 cycles required by resources/recurrence
#<swps>      min  12 cycles required for critical path
#<swps>           27 cycles non-loop schedule length

#<swps>    register file usage:
#<swps>      'a' total 10 out of 16 [2-3,8-15]
#<swps>      'b' total 1 out of 16 [0]
#<swps>      'aed' total 14 out of 16 [0-13]
*/
        do            
        {
            
            int offset_inc = 0; 
            acc+=acc_inc;
            XT_MOVEQZ(offset_inc, tw_step*4, acc); 

            ae_int32x2 t1, t2, t3; 
            ae_f16x4 t1_f16x4; 
            ae_f16x4 t2_f16x4; 
            ae_f16x4 t3_f16x4; 
            
            vA3 = AE_L32X2_X( px,  3*8*stride); 
            vA2 = AE_L32X2_X(  px,  2*8*stride); 
            vA1 = AE_L32X2_X(  px,  1*8*stride); 
            AE_L32X2_XC(vA0, px,  4*8*stride); 

            vA3 = AE_SRAS32(vA3); 
            vA2 = AE_SRAS32(vA2); 
            vA1 = AE_SRAS32(vA1); 
            vA0 = AE_SRAS32(vA0); 

            vB0 = AE_ADD32S(vA0, vA2);
            vB2 = AE_SUB32S(vA0, vA2);
            vB1 = AE_ADD32S(vA1, vA3);
            vB3 = AE_SUB32S(vA1, vA3);
            
            vB3 = AE_SEL32_LH(vB3, vB3);

            vC0 = AE_ADD32S(vB0, vB1);
            vC2 = AE_SUB32S(vB0, vB1);
            vC3 = AE_SUBADD32S(vB2, vB3);
            vC1 = AE_ADDSUB32S(vB2, vB3);

            AE_L32_XP( t1 ,p16tw1, offset_inc);
            AE_L32_XP( t2 ,p16tw2, offset_inc);
            AE_L32_XP( t3 ,p16tw3, offset_inc);

            t1_f16x4 = AE_MOVF16X4_FROMINT32X2(t1);            
            t2_f16x4 = AE_MOVF16X4_FROMINT32X2(t2); 
            t3_f16x4 = AE_MOVF16X4_FROMINT32X2(t3); 

            vC1 = AE_MULFC32X16RAS_L(vC1, t1_f16x4); 
            vC2 = AE_MULFC32X16RAS_L(vC2, t2_f16x4); 
            vC3 = AE_MULFC32X16RAS_L(vC3, t3_f16x4); 

            AE_S32X2_X (vC3, py,  3*8*stride); 
            AE_S32X2_X (vC2, py,  1*8*stride); 
            AE_S32X2_X (vC1, py,  2*8*stride); 
            AE_S32X2_XC(vC0, py,  4*8*stride);     


        }while(--i);

        stride>>=2;  
        tw_step<<=2;

    }
  
    shift += fft_stage_last_ie((int32_t*)x, (int32_t*)y, N); 

  return shift;
} /* fft_cplx32x16_ie() */
  
